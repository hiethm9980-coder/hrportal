import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hr_portal/core/constants/app_colors.dart';
import 'package:hr_portal/core/constants/app_shadows.dart';
import 'package:hr_portal/core/localization/app_localizations.dart';
import 'package:hr_portal/shared/widgets/common_widgets.dart';

import '../../../../shared/widgets/shared_widgets.dart';
import '../../../../shared/controllers/global_error_handler.dart';
import '../../data/models/manager_request_models.dart';
import '../providers/manager_request_providers.dart';

// ═══════════════════════════════════════════════════════════════════
// Manager Requests List Screen (Approvals)
// ═══════════════════════════════════════════════════════════════════

class ManagerRequestsScreen extends ConsumerWidget {
  const ManagerRequestsScreen({super.key});

  static const _statusFilters = [
    (null, 'All'),
    ('pending', 'Pending'),
    ('processing', 'Processing'),
    ('approved', 'Approved'),
    ('rejected', 'Rejected'),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.read(managerRequestsListProvider.notifier);

    return Scaffold(
      backgroundColor: context.appColors.bg,
      body: Column(
        children: [
          CustomAppBar(
            title: 'Approvals'.tr(context),
            onRefresh: () => controller.refresh(),
          ),

          // ── Status Filter Tabs ──
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SizedBox(
              height: 36,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _statusFilters.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final filter = _statusFilters[index];
                  final isActive = controller.statusFilter == filter.$1;
                  return GestureDetector(
                    onTap: () => controller.setStatusFilter(filter.$1),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: isActive
                            ? AppColors.primaryMid
                            : context.appColors.bgCard,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isActive
                              ? AppColors.primaryMid
                              : context.appColors.gray200,
                        ),
                      ),
                      child: Text(
                        filter.$2.tr(context),
                        style: GoogleFonts.cairo(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: isActive
                              ? Colors.white
                              : context.appColors.textSecondary,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // ── List ──
          Expanded(
            child: PaginatedListView<ManagerRequest>(
              state: ref.watch(managerRequestsListProvider),
              onRefresh: () => controller.refresh(),
              onLoadMore: () => controller.loadMore(),
              emptyIcon: Icons.assignment_turned_in,
              emptyTitle: 'No pending requests'.tr(context),
              emptySubtitle:
                  'Employee requests will appear here'.tr(context),
              itemBuilder: (context, request) =>
                  _ManagerRequestTile(request: request),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// Manager Request Tile
// ═══════════════════════════════════════════════════════════════════

class _ManagerRequestTile extends StatelessWidget {
  final ManagerRequest request;
  const _ManagerRequestTile({required this.request});

  String _statusType(String status) {
    switch (status) {
      case 'approved':
      case 'completed':
        return 'approved';
      case 'rejected':
        return 'rejected';
      case 'pending':
      case 'processing':
        return 'pending';
      case 'cancelled':
        return 'navy';
      default:
        return 'info';
    }
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Rejected';
      case 'pending':
        return 'Pending';
      case 'processing':
        return 'Processing';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status;
    }
  }

  String _typeLabel(String? type) {
    switch (type) {
      case 'salary_certificate':
        return 'Salary certificate';
      case 'experience_letter':
        return 'Experience letter';
      case 'vacation_settlement':
        return 'Vacation settlement';
      case 'loan_request':
        return 'Loan request';
      case 'expense_claim':
        return 'Expense claim';
      case 'training_request':
        return 'Training request';
      case 'other':
        return 'Other';
      default:
        return type ?? 'Request';
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _showDetailSheet(context),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: context.appColors.bgCard,
          borderRadius: BorderRadius.circular(16),
          boxShadow: AppShadows.card,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Row 1: Subject + Status ──
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text(
                    request.subject ??
                        _typeLabel(request.requestType).tr(context),
                    style: GoogleFonts.cairo(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: context.appColors.textPrimary,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                ),
                const SizedBox(width: 8),
                StatusBadge(
                  text: _statusLabel(request.status).tr(context),
                  type: _statusType(request.status),
                  dot: true,
                ),
              ],
            ),
            const SizedBox(height: 6),

            // ── Row 2: Employee + Type + Date ──
            Row(
              children: [
                if (request.employee != null) ...[
                  Icon(Icons.person_outline,
                      size: 14, color: context.appColors.textMuted),
                  const SizedBox(width: 4),
                  Text(
                    request.employee!.name,
                    style: GoogleFonts.cairo(
                        fontSize: 11, color: context.appColors.textMuted),
                  ),
                  const SizedBox(width: 12),
                ],
                Text(
                  _typeLabel(request.requestType).tr(context),
                  style: GoogleFonts.cairo(
                      fontSize: 11, color: context.appColors.textMuted),
                ),
                const Spacer(),
                Text(
                  request.createdAt.length >= 10
                      ? request.createdAt.substring(0, 10)
                      : request.createdAt,
                  style: GoogleFonts.cairo(
                      fontSize: 11, color: context.appColors.textMuted),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showDetailSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      backgroundColor: context.appColors.bgCard,
      builder: (_) => _ManagerRequestDetailSheet(request: request),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// Manager Request Detail Bottom Sheet (with approve/reject)
// ═══════════════════════════════════════════════════════════════════

class _ManagerRequestDetailSheet extends ConsumerStatefulWidget {
  final ManagerRequest request;
  const _ManagerRequestDetailSheet({required this.request});

  @override
  ConsumerState<_ManagerRequestDetailSheet> createState() =>
      _ManagerRequestDetailSheetState();
}

class _ManagerRequestDetailSheetState
    extends ConsumerState<_ManagerRequestDetailSheet> {
  final _notesController = TextEditingController();

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  String _statusType(String status) {
    switch (status) {
      case 'approved':
      case 'completed':
        return 'approved';
      case 'rejected':
        return 'rejected';
      case 'pending':
      case 'processing':
        return 'pending';
      default:
        return 'info';
    }
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Rejected';
      case 'pending':
        return 'Pending';
      case 'processing':
        return 'Processing';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status;
    }
  }

  String _typeLabel(String? type) {
    switch (type) {
      case 'salary_certificate':
        return 'Salary certificate';
      case 'experience_letter':
        return 'Experience letter';
      case 'vacation_settlement':
        return 'Vacation settlement';
      case 'loan_request':
        return 'Loan request';
      case 'expense_claim':
        return 'Expense claim';
      case 'training_request':
        return 'Training request';
      case 'other':
        return 'Other';
      default:
        return type ?? 'Request';
    }
  }

  bool get _canDecide {
    final s = widget.request.status;
    return s == 'pending' || s == 'processing';
  }

  void _handleDecide(String status) {
    final notes = _notesController.text.trim();

    // Reject requires notes
    if (status == 'rejected' && notes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Rejection notes are required'.tr(context)),
          behavior: SnackBarBehavior.floating,
          backgroundColor: AppColors.error,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }

    ref.read(decideRequestProvider.notifier).decide(
          requestId: widget.request.id,
          status: status,
          responseNotes: notes.isNotEmpty ? notes : null,
        );
  }

  @override
  Widget build(BuildContext context) {
    final decideState = ref.watch(decideRequestProvider);

    ref.listen<DecideRequestState>(decideRequestProvider, (prev, next) {
      if (next.isSuccess && prev?.isSuccess != true) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Decision submitted successfully'.tr(context)),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
      if (next.error != null && prev?.error != next.error) {
        GlobalErrorHandler.show(context, next.error!);
      }
    });

    final r = widget.request;

    return Padding(
      padding: EdgeInsets.only(
        top: 16,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── Handle ──
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: context.appColors.gray200,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),

            // ── Title & Status ──
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Padding(
                    padding:
                        const EdgeInsetsDirectional.only(end: 10, top: 2),
                    child: Icon(Icons.close,
                        size: 22, color: context.appColors.textMuted),
                  ),
                ),
                Expanded(
                  child: Text(
                    r.subject ?? _typeLabel(r.requestType).tr(context),
                    style: GoogleFonts.cairo(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: context.appColors.textPrimary,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                StatusBadge(
                  text: _statusLabel(r.status).tr(context),
                  type: _statusType(r.status),
                  dot: true,
                ),
              ],
            ),
            const SizedBox(height: 20),

            // ── Info Rows ──
            if (r.employee != null)
              _InfoRow(
                icon: '👤',
                label: 'Employee'.tr(context),
                value: '${r.employee!.name} (${r.employee!.code})',
              ),
            _InfoRow(
              icon: '📋',
              label: 'Type'.tr(context),
              value: _typeLabel(r.requestType).tr(context),
            ),
            _InfoRow(
              icon: '📅',
              label: 'Created at'.tr(context),
              value: r.createdAt.length >= 10
                  ? r.createdAt.substring(0, 10)
                  : r.createdAt,
            ),
            if (r.description != null && r.description!.isNotEmpty)
              _InfoRow(
                icon: '📝',
                label: 'Details'.tr(context),
                value: r.description!,
                multiLine: true,
              ),
            if (r.responseNotes != null && r.responseNotes!.isNotEmpty)
              _InfoRow(
                icon: '💬',
                label: 'Response notes'.tr(context),
                value: r.responseNotes!,
                multiLine: true,
              ),
            if (r.respondedAt != null)
              _InfoRow(
                icon: '⏰',
                label: 'Responded at'.tr(context),
                value: r.respondedAt!.length >= 10
                    ? r.respondedAt!.substring(0, 10)
                    : r.respondedAt!,
              ),

            // ── Decision Section ──
            if (_canDecide) ...[
              const SizedBox(height: 16),
              Divider(color: context.appColors.gray200),
              const SizedBox(height: 12),

              // ── Response Notes Input ──
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(
                  'Response notes'.tr(context),
                  style: GoogleFonts.cairo(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: context.appColors.textSecondary,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: _notesController,
                maxLines: 3,
                enabled: !decideState.isLoading,
                style: GoogleFonts.cairo(fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Add notes (required for rejection)'.tr(context),
                  hintStyle: GoogleFonts.cairo(
                      fontSize: 12, color: context.appColors.textMuted),
                  errorText: decideState.fieldError('response_notes'),
                ),
              ),
              const SizedBox(height: 16),

              // ── Action Buttons ──
              if (decideState.isLoading)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Center(child: CircularProgressIndicator()),
                )
              else
                Row(
                  children: [
                    // ── Reject Button ──
                    Expanded(
                      child: AppOutlineButton(
                        text: 'Reject'.tr(context),
                        color: AppColors.error,
                        small: true,
                        onTap: () => _handleDecide('rejected'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    // ── Approve Button ──
                    Expanded(
                      child: TealButton(
                        text: 'Approve'.tr(context),
                        icon: '✓',
                        small: true,
                        onTap: () => _handleDecide('approved'),
                      ),
                    ),
                  ],
                ),
            ],
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// Info Row Widget
// ═══════════════════════════════════════════════════════════════════

class _InfoRow extends StatelessWidget {
  final String icon;
  final String label;
  final String value;
  final bool multiLine;

  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
    this.multiLine = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment:
            multiLine ? CrossAxisAlignment.start : CrossAxisAlignment.center,
        children: [
          Text(icon, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.cairo(
                    fontSize: 11,
                    color: context.appColors.textMuted,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: GoogleFonts.cairo(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: context.appColors.textPrimary,
                  ),
                  maxLines: multiLine ? 10 : 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
