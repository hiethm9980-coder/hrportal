import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hr_portal/core/constants/app_colors.dart';
import 'package:hr_portal/core/constants/app_shadows.dart';
import 'package:hr_portal/core/localization/app_localizations.dart';
import 'package:hr_portal/core/theme/app_spacing.dart';
import 'package:hr_portal/shared/widgets/common_widgets.dart';

import '../../../../shared/controllers/global_error_handler.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../../data/models/attendance_models.dart';
import '../providers/attendance_providers.dart';

class AttendanceScreen extends ConsumerWidget {
  const AttendanceScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Listen for check-in/out errors and show dialog/snackbar.
    ref.listen<CheckActionState>(checkActionProvider, (prev, next) {
      final error = next.error;
      if (error != null) {
        GlobalErrorHandler.show(context, error);
        ref.read(checkActionProvider.notifier).clearError();
      }

      // Success: show a simple snackbar.
      if (next.record != null && (prev?.record?.id != next.record!.id)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Attendance record updated successfully'.tr(context)),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    });

    final checkAction = ref.watch(checkActionProvider);

    final historyState = ref.watch(attendanceHistoryProvider);
    final historyController = ref.read(attendanceHistoryProvider.notifier);
    final summary = historyController.summary;

    return Scaffold(
      backgroundColor: context.appColors.bg,
      body: Column(
        children: [
          // ── Gradient Header ──
          CustomAppBar(
            title: 'Attendance'.tr(context),
            subtitle: 'Attendance summary — current month'.tr(context),
            onRefresh: () => ref.read(attendanceHistoryProvider.notifier).refresh(),
          ),

          // ── Check In / Out Buttons ──
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: TealButton(
                    text: 'Check in'.tr(context),
                    icon: '▶',
                    small: true,
                    onTap: checkAction.isLoading
                        ? null
                        : () => ref.read(checkActionProvider.notifier).checkIn(),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: AppOutlineButton(
                    text: 'Check out'.tr(context),
                    color: AppColors.error,
                    small: true,
                    onTap: checkAction.isLoading
                        ? null
                        : () => ref.read(checkActionProvider.notifier).checkOut(),
                  ),
                ),
              ],
            ),
          ),

          if (checkAction.isLoading)
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: LinearProgressIndicator(color: AppColors.primaryMid),
            ),

          if (summary != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _SummaryCard(summary: summary),
            ),

          const SizedBox(height: 12),

          Expanded(
            child: PaginatedListView<AttendanceRecord>(
              state: historyState,
              onRefresh: () =>
                  ref.read(attendanceHistoryProvider.notifier).refresh(),
              onLoadMore: () =>
                  ref.read(attendanceHistoryProvider.notifier).loadMore(),
              itemBuilder: (context, record) => _RecordTile(record: record),
              emptyIcon: null,
              emptyTitle: '',
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final AttendanceSummary summary;
  const _SummaryCard({required this.summary});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _Stat(
              label: 'Present'.tr(context),
              value: '${summary.presentDays}',
              color: AppColors.success),
          _Stat(
              label: 'Absent'.tr(context),
              value: '${summary.absentDays}',
              color: AppColors.error),
          _Stat(
              label: 'Late'.tr(context),
              value: '${summary.lateDays}',
              color: AppColors.warning),
          _Stat(
              label: 'Leave'.tr(context),
              value: '${summary.leaveDays}',
              color: AppColors.info),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _Stat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(value,
            style: GoogleFonts.cairo(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              color: color,
              height: 1.1,
            )),
        const SizedBox(height: 4),
        Text(label,
            style: GoogleFonts.cairo(fontSize: 11, color: context.appColors.textMuted)),
      ],
    );
  }
}

class _RecordTile extends StatelessWidget {
  final AttendanceRecord record;
  const _RecordTile({required this.record});

  String _statusType(String status) {
    switch (status.toLowerCase()) {
      case 'present':
        return 'approved';
      case 'absent':
        return 'rejected';
      case 'late':
        return 'pending';
      default:
        return 'info';
    }
  }

  String _statusLabel(String status) {
    switch (status.toLowerCase()) {
      case 'present':
        return 'Present';
      case 'absent':
        return 'Absent';
      case 'late':
        return 'Late';
      case 'leave':
        return 'Leave';
      default:
        return status;
    }
  }

  void _showDetailSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      backgroundColor: context.appColors.bgCard,
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          top: 16,
          left: 20,
          right: 20,
          bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── Handle ──
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: context.appColors.gray200,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),

            // ── Title & Status ──
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Padding(
                    padding:
                        const EdgeInsetsDirectional.only(end: 10, top: 2),
                    child: Icon(Icons.close,
                        size: 22, color: context.appColors.textMuted),
                  ),
                ),
                Expanded(
                  child: Text(
                    record.date,
                    style: GoogleFonts.cairo(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: context.appColors.textPrimary,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                StatusBadge(
                  text: _statusLabel(record.status).tr(context),
                  type: _statusType(record.status),
                  dot: true,
                ),
              ],
            ),
            const SizedBox(height: 20),

            // ── Info Rows ──
            _AttendanceDetailRow(
              icon: '📊',
              label: 'Status'.tr(context),
              value: _statusLabel(record.status).tr(context),
            ),
            if (record.checkInTime != null)
              _AttendanceDetailRow(
                icon: '▶',
                label: 'Check in'.tr(context),
                value: record.checkInTime!,
              ),
            if (record.checkOutTime != null)
              _AttendanceDetailRow(
                icon: '⏹',
                label: 'Check out'.tr(context),
                value: record.checkOutTime!,
              ),
            _AttendanceDetailRow(
              icon: '⏱',
              label: 'Worked hours'.tr(context),
              value: record.workedHours.toStringAsFixed(1),
            ),
            if (record.overtimeMinutes > 0)
              _AttendanceDetailRow(
                icon: '⏰',
                label: 'Overtime'.tr(context),
                value: '${record.overtimeMinutes} ${'min'.tr(context)}',
              ),
            if (record.lateMinutes > 0)
              _AttendanceDetailRow(
                icon: '⚠',
                label: 'Late'.tr(context),
                value: '${record.lateMinutes} ${'min'.tr(context)}',
              ),
            if (record.earlyDepartureMinutes > 0)
              _AttendanceDetailRow(
                icon: '🚪',
                label: 'Early departure'.tr(context),
                value: '${record.earlyDepartureMinutes} ${'min'.tr(context)}',
              ),
            if (record.shortageMinutes > 0)
              _AttendanceDetailRow(
                icon: '📉',
                label: 'Shortage'.tr(context),
                value: '${record.shortageMinutes} ${'min'.tr(context)}',
              ),
            if (record.scheduledStart != null)
              _AttendanceDetailRow(
                icon: '🕐',
                label: 'Scheduled start'.tr(context),
                value: record.scheduledStart!,
              ),
            if (record.scheduledEnd != null)
              _AttendanceDetailRow(
                icon: '🕐',
                label: 'Scheduled end'.tr(context),
                value: record.scheduledEnd!,
              ),
            if (record.checkInSource != null)
              _AttendanceDetailRow(
                icon: '📍',
                label: 'Check in source'.tr(context),
                value: record.checkInSource!,
              ),
            if (record.checkOutSource != null)
              _AttendanceDetailRow(
                icon: '📍',
                label: 'Check out source'.tr(context),
                value: record.checkOutSource!,
              ),
            if (record.notes != null && record.notes!.isNotEmpty)
              _AttendanceDetailRow(
                icon: '📝',
                label: 'Notes'.tr(context),
                value: record.notes!,
                multiLine: true,
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final statusType = record.status == 'present' ? 'success' : 'error';

    return GestureDetector(
      onTap: () => _showDetailSheet(context),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: context.appColors.bgCard,
          borderRadius: BorderRadius.circular(16),
          boxShadow: AppShadows.card,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                StatusBadge(text: record.status, type: statusType, dot: true),
                if (record.checkInTime != null) ...[
                  const SizedBox(width: 8),
                  Text(
                    '${'In'.tr(context)}: ${record.checkInTime}',
                    style: GoogleFonts.cairo(fontSize: 11, color: context.appColors.textMuted),
                  ),
                ],
                if (record.checkOutTime != null) ...[
                  const SizedBox(width: 8),
                  Text(
                    '${'Out'.tr(context)}: ${record.checkOutTime}',
                    style: GoogleFonts.cairo(fontSize: 11, color: context.appColors.textMuted),
                  ),
                ],
              ],
            ),
            Text(
              record.date,
              style: GoogleFonts.cairo(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: context.appColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AttendanceDetailRow extends StatelessWidget {
  final String icon;
  final String label;
  final String value;
  final bool multiLine;

  const _AttendanceDetailRow({
    required this.icon,
    required this.label,
    required this.value,
    this.multiLine = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment:
            multiLine ? CrossAxisAlignment.start : CrossAxisAlignment.center,
        children: [
          Text(icon, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.cairo(
                    fontSize: 11,
                    color: context.appColors.textMuted,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: GoogleFonts.cairo(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: context.appColors.textPrimary,
                  ),
                  maxLines: multiLine ? 10 : 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
